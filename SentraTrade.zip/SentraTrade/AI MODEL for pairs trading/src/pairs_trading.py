import pandas as pd
import requests
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from textblob import TextBlob
from transformers import pipeline
import openai

# Set up OpenAI API key (if using OpenAI GPT-3 for sentiment analysis)
openai.api_key = 'Your_API'# Use your API 

# Define tickers of interest
tickers = ['AMZN', 'MSFT', 'META', 'JPM', 'SLB', 'PEP', 'KO', 'HD', 'LOW', 'V', 'MA', 'BAC']

# Initialize sentiment analysis models
vader_analyzer = SentimentIntensityAnalyzer()
openai_analyzer = pipeline('sentiment-analysis', model="textattack/bert-base-uncased-SST-2")

# Function to fetch news articles for a given ticker
def fetch_news_articles(ticker):
    url = 'https://newsapi.org/v2/everything'
    params = {
        'q': ticker,
        'apiKey': 'YOUR_API'  # Replace with your News API key
    }
    response = requests.get(url, params=params)
    if response.status_code == 200:
        return response.json().get('articles', [])
    else:
        print(f"Error fetching news articles for {ticker}: {response.text}")
        return []

# Function to perform sentiment analysis on articles
def analyze_sentiment(article, ticker):
    title = article['title']
    content = article['content']
    date = article['publishedAt'].split('T')[0]  # Extract date from publishedAt field

    # Sentiment analysis on title
    vader_title_score = vader_analyzer.polarity_scores(title)['compound']
    textblob_title_score = TextBlob(title).sentiment.polarity
    openai_title_score = openai_analyzer(title)[0]['score']

    # Sentiment analysis on content
    vader_content_score = vader_analyzer.polarity_scores(content)['compound']
    textblob_content_score = TextBlob(content).sentiment.polarity
    openai_content_score = openai_analyzer(content)[0]['score']

    # Average sentiment scores of title and content
    vader_avg_score = (vader_title_score + vader_content_score) / 2
    textblob_avg_score = (textblob_title_score + textblob_content_score) / 2
    openai_avg_score = (openai_title_score + openai_content_score) / 2

    return {
        'Ticker': ticker,
        'Date': date,
        'Vader Title Sentiment Score': vader_title_score,
        'TextBlob Title Sentiment Score': textblob_title_score,
        'OpenAI Title Sentiment Score': openai_title_score,
        'Vader Content Sentiment Score': vader_content_score,
        'TextBlob Content Sentiment Score': textblob_content_score,
        'OpenAI Content Sentiment Score': openai_content_score,
        'Vader Average Sentiment Score': vader_avg_score,
        'TextBlob Average Sentiment Score': textblob_avg_score,
        'OpenAI Average Sentiment Score': openai_avg_score
    }

# Main function
def main():
    all_articles = []

    # Fetch news articles for each ticker
    for ticker in tickers:
        articles = fetch_news_articles(ticker)
        all_articles.extend([(ticker, article) for article in articles])

    # Analyze sentiment for each article using different models
    sentiment_scores = []
    for ticker, article in all_articles:
        sentiment_scores.append(analyze_sentiment(article, ticker))

    # Create a DataFrame from sentiment scores
    df = pd.DataFrame(sentiment_scores)

    # Save sentiment scores to an Excel file
    df.to_excel('sentiment_scores.xlsx', index=False)

if __name__ == "__main__":
    main()
