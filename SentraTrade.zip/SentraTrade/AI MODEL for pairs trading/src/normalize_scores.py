import pandas as pd

# Load the dataset
data = pd.read_excel("sentiment_scores.xlsx")

# Aggregate title and content sentiment scores
data['Title_Avg_Score'] = (data['Vader Title Sentiment Score'] + data['TextBlob Title Sentiment Score'] + data['OpenAI Title Sentiment Score']) / 3
data['Content_Avg_Score'] = (data['Vader Content Sentiment Score'] + data['TextBlob Content Sentiment Score'] + data['OpenAI Content Sentiment Score']) / 3

# Calculate average sentiment score
data['Average_Score'] = (data['Title_Avg_Score'] + data['Content_Avg_Score']) / 2

# Normalize scores
data['Normalized_Score'] = (data['Average_Score'] - data['Average_Score'].min()) / (data['Average_Score'].max() - data['Average_Score'].min())

# Display the normalized scores
data[['Ticker', 'Date', 'Normalized_Score']].to_excel('normalized_scores.xlsx', index=False)