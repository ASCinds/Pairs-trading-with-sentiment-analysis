import os
from app import create_app
from config import DevelopmentConfig, ProductionConfig

# Choose the configuration class based on an environment variable
env = os.getenv('FLASK_ENV', 'development')
config_class = DevelopmentConfig if env == 'development' else ProductionConfig

app = create_app(config_class)

if __name__ == '__main__':
    app.run(ssl_context=('cert.pem', 'key.pem'))
