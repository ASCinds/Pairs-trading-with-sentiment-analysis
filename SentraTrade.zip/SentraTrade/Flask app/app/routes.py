from flask import render_template, url_for, flash, redirect, request, Blueprint
import sqlalchemy
from app import db
from app.models import User, Enrollment
from app.forms import EnrollmentForm
from app.forms import RegistrationForm, LoginForm, ContactForm
from flask_login import login_user, current_user, logout_user, login_required
from newsapi import NewsApiClient
from textblob import TextBlob
from werkzeug.security import generate_password_hash, check_password_hash
from app.models import UserPreference
from .api_utils import fetch_stock_news, fetch_stock_price



main = Blueprint('main', __name__)
newsapi = NewsApiClient(api_key='YOur_API') # Please use your news APi




@main.route("/")
@main.route("/home")
def home():
    return render_template('index.html', title='Home')

@main.route('/about')
@login_required
def about():
    return render_template('about.html', title='About')

@main.route("/aimodel", methods=['GET', 'POST']) 
@login_required
def aimodel():  
    
    
    api_key_prices = 'Your_Api'  # Your Alpha Vantage API key

    stock_pairs = {
        "META_AMZN": ("META", "AMZN"),
        "HD_LOW": ("HD", "LOW"),
        "JPM_BAC": ("JPM", "BAC"),
        "V_MA": ("V", "MA"),
        "SLB_HAL": ("SLB", "HAL"),
        "META_MSFT": ("META", "MSFT"),
        "PEP_KO": ("PEP", "KO")
    }
    
    # Prepare the template variables
    ticker = None
    trading_call = None
    image_url = None
    stock_news = {}
    stock_prices = {}

    if request.method == 'POST':
        tickers = request.form.get('pair', 'META_AMZN')  # Ensures a default pair
        ticker1, ticker2 = stock_pairs.get(tickers, ("META", "AMZN"))

        # News and sentiment analysis
        ticker1_articles = newsapi.get_everything(q=ticker1)
        ticker2_articles = newsapi.get_everything(q=ticker2)
        ticker1_sentiment_scores = [TextBlob(article['content']).sentiment.polarity for article in ticker1_articles['articles']]
        ticker2_sentiment_scores = [TextBlob(article['content']).sentiment.polarity for article in ticker2_articles['articles']]
        average_ticker1_sentiment = sum(ticker1_sentiment_scores) / len(ticker1_sentiment_scores) if ticker1_sentiment_scores else 0
        average_ticker2_sentiment = sum(ticker2_sentiment_scores) / len(ticker2_sentiment_scores) if ticker2_sentiment_scores else 0

        # Determine trading strategy based on sentiment
        trading_call = 'Long {} and Short {}'.format(ticker1, ticker2) if average_ticker1_sentiment > average_ticker2_sentiment else 'Long {} and Short {}'.format(ticker2, ticker1)
        ticker = tickers  # This will ensure `ticker` is available for the template
        image_url = f'images/{ticker1}_{ticker2}_returns_chart.png'

        # Fetch and store prices and news for display
        stock_news[ticker1] = newsapi.get_everything(q=ticker1)['articles'][:5]
        stock_news[ticker2] = newsapi.get_everything(q=ticker2)['articles'][:5]
        stock_prices[ticker1] = fetch_stock_price(api_key_prices, ticker1)
        stock_prices[ticker2] = fetch_stock_price(api_key_prices, ticker2)

    return render_template('ai_model.html', ticker=ticker, trading_call=trading_call, image_url=image_url, 
                           stock_news=stock_news, stock_prices=stock_prices, stock_pairs=stock_pairs.keys())

@main.route("/education")
@login_required
def education():
    return render_template('education.html', title='Education')

@main.route('/enroll', methods=['GET', 'POST'])
@login_required
def enroll():
    form = EnrollmentForm()
    if form.validate_on_submit():
        existing_enrollment = Enrollment.query.filter_by(email=form.email.data).first()
        if existing_enrollment:
            flash('This email has already been used to enroll. Please use a different email or contact support if you think this is an error.', 'error')
            return redirect(url_for('main.enroll'))
        
        enrollment = Enrollment(email=form.email.data, interests=','.join(form.interests.data))
        db.session.add(enrollment)
        try:
            db.session.commit()
            flash('Thank you for your enrollment!', 'success')
        except sqlalchemy.exc.IntegrityError:
            db.session.rollback()
            flash('This email has already been registered.', 'error')
        return redirect(url_for('main.about'))
    return render_template('enroll.html', title='Enroll in Updates', form=form)

@main.route("/faq")
def faq():
    return render_template('faq.html', title='FAQ')

@main.route("/contact", methods=['GET', 'POST'])
def contact():
    form = ContactForm()
    if form.validate_on_submit():
        flash('Thank you for your message! We will get back to you soon.', 'success')
        return redirect(url_for('main.home'))
    return render_template('contact.html', title='Contact Us', form=form)

@main.route("/login", methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.about'))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and check_password_hash(user.password_hash, form.password.data):
            login_user(user, remember=form.remember.data)
            flash('Login successful! Welcome back!', 'success')
            return redirect(url_for('main.about'))
        else:
            flash('Invalid username or password. Please try again.', 'error')
    return render_template('login.html', title='Login', form=form)

@main.route("/logout")
def logout():
    logout_user()
    return redirect(url_for('main.home'))


@main.route("/register", methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('main.home'))
    form = RegistrationForm()
    if form.validate_on_submit():
        # Check if email already exists
        existing_user = User.query.filter_by(email=form.email.data).first()
        if existing_user:
            flash('Email already registered. Please use a different email or log in.', 'error')
            return redirect(url_for('main.register'))

        hashed_password = generate_password_hash(form.password.data)
        user = User(username=form.username.data, email=form.email.data, password_hash=hashed_password)
        try:
            db.session.add(user)
            db.session.commit()
            flash('Congratulations! Your account has been created! You can now log in.', 'success')
            return redirect(url_for('main.login'))
        except Exception as e:
            db.session.rollback()
            flash(f'An error occurred during registration: {str(e)}', 'error')

    for field, errors in form.errors.items():
        for error in errors:
            flash(f"Error in the {getattr(form, field).label.text}: {error}", 'error')

    return render_template('register.html', title='Register', form=form)

