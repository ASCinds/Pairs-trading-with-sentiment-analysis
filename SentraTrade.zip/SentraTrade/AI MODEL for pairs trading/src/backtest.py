import argparse
import datetime
import pandas as pd
import yfinance as yf
from datetime import datetime, timedelta
import plotly.graph_objs as go
import plotly.io as pio

def fetch_sentiment(ticker):
    # Read sentiment data from Excel file
    df = pd.read_excel("normalized_scores.xlsx", names=["Ticker", "Date", "Sentiment"])

    # Filter data for the given ticker and the last 30 days
    end_date = datetime.now().strftime('%Y-%m-%d')
    start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
    df_filtered = df[(df["Ticker"] == ticker) & (df["Date"] >= start_date) & (df["Date"] <= end_date)]

    # Convert data to dictionary format
    sentiment_data = dict(zip(df_filtered["Date"], df_filtered["Sentiment"]))

    return sentiment_data


# Function to fetch stock prices from Yahoo Finance
def fetch_stock_prices(tickers):
    end_date = datetime.now().strftime('%Y-%m-%d')
    start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
    data = yf.download(tickers, start=start_date, end=end_date)
    return data["Close"]

def calculate_PnL(df, ticker1, ticker2):
    threshold = 0.2
    initial_investment = 1000
    returns = []
    cash = initial_investment
    pnl = 0
    pnls = []
    dates = []

    for date, row in df.iterrows():

        if abs(row[f'{ticker1}_score'] - row[f'{ticker2}_score']) > threshold:

            # Check if the sentiment of 1 is greater than the sentiment of t2
            if row[f'{ticker1}_score'] > row[f'{ticker2}_score']:
                returns.append(1 + row[ticker2]+(-1 * row[ticker1]))
            elif row[f'{ticker2}_score'] > row[f'{ticker1}_score']:
                returns.append(1 + row[ticker1]+(-1 * row[ticker2]))

        else:
            returns.append(1)  

        dates.append(date)  

    cummulative_returns = []
    cr = 1

    for ret in returns:
        cash = cash * ret
        pnls.append(cash)
        cr = cr * ret
        cummulative_returns.append(cr)

    pnl = cash - initial_investment
    
    

        

    return pnl, pnls, cummulative_returns, dates


def plot_and_save_line_chart(x, y, filename):
    # Create a Plotly figure
    fig = go.Figure()

    # Add trace for the line chart
    fig.add_trace(go.Scatter(x=x, y=y, mode='lines', name='PnL'))

    # Set layout for the chart
    fig.update_layout(title='Profit and Loss Over Time', xaxis_title='Date', yaxis_title='PnL')

    # Save the chart as a picture
    pio.write_image(fig, filename)


# Main function
def main(tickers):
    # Fetch news sentiment for each ticker
    all_sentiments = {}
    for ticker in tickers:
        sentiment_data = fetch_sentiment(ticker)
        all_sentiments[ticker] = sentiment_data

    ticker1, ticker2 = tickers

    # Fetch stock prices
    stock_prices = fetch_stock_prices(tickers)
    stock_returns = (stock_prices - stock_prices.shift(1))/stock_prices.shift(1)
    df = pd.DataFrame.from_dict(all_sentiments)
    df.columns = [f'{ticker1}_score', f'{ticker2}_score']
    df.index = pd.to_datetime(df.index)
    df.sort_index(inplace=True)
    df.fillna(0, inplace=True)
    df = pd.concat([stock_returns, df], axis = 1)
    df = df.dropna()

    pnl, pnls, returns, dates = calculate_PnL(df, ticker1, ticker2)

    plot_and_save_line_chart(dates, pnls, f'{ticker1}_{ticker2}_pnls_chart.png')
    plot_and_save_line_chart(dates, returns, f'{ticker1}_{ticker2}_returns_chart.png')

    print(f"Profit for {ticker1} and {ticker2} trades:  {pnl}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Fetch news sentiment and stock prices")
    parser.add_argument("tickers", nargs="+", help="List of ticker symbols")
    args = parser.parse_args()
    main(args.tickers)
