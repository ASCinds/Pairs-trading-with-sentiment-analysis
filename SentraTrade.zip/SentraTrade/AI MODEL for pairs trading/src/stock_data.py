import argparse
import pandas as pd
import yfinance as yf
from datetime import datetime, timedelta
from openpyxl import Workbook

def fetch_price_data(symbol, start_date, end_date):
    """
    Fetch historical price data for a stock symbol from Yahoo Finance.

    Args:
        symbol (str): Stock ticker symbol (e.g., 'AAPL' for Apple Inc.).
        start_date (str): Start date for data retrieval in 'YYYY-MM-DD' format.
        end_date (str): End date for data retrieval in 'YYYY-MM-DD' format.

    Returns:
        pd.DataFrame: Historical price data.
    """
    data = yf.download(symbol, start=start_date, end=end_date)
    return data

def preprocess_data(data):
    """
    Preprocess historical price data.

    Args:
        data (pd.DataFrame): DataFrame containing historical price data.

    Returns:
        pd.DataFrame: Preprocessed DataFrame with cleaned data.
    """
    df = data.dropna()  # Drop rows with missing values
    return df

def find_correlation(data1, data2):
    """
    Find correlation between two sets of data.

    Args:
        data1 (pd.DataFrame): Historical price data for stock 1.
        data2 (pd.DataFrame): Historical price data for stock 2.

    Returns:
        float: Correlation coefficient.
    """
    return data1['Close'].corr(data2['Close'])  # Assuming 'Close' is the column for closing price

def save_to_excel(df1, df2, symbol1, symbol2):
    """
    Save preprocessed data to an Excel file.

    Args:
        df1 (pd.DataFrame): Preprocessed data for stock 1.
        df2 (pd.DataFrame): Preprocessed data for stock 2.
        symbol1 (str): Stock ticker symbol for stock 1.
        symbol2 (str): Stock ticker symbol for stock 2.
    """
    wb = Workbook()
    ws = wb.active
    ws.append(['Date', f'{symbol1}_Open', f'{symbol1}_High', f'{symbol1}_Low', f'{symbol1}_Close', f'{symbol1}_Volume',
               f'{symbol2}_Open', f'{symbol2}_High', f'{symbol2}_Low', f'{symbol2}_Close', f'{symbol2}_Volume'])

    merged_data = pd.merge(df1, df2, left_index=True, right_index=True, suffixes=('_'+symbol1, '_'+symbol2))
    for index, row in merged_data.iterrows():
        ws.append([index] + list(row))

    wb.save(f'{symbol1}_{symbol2}_stock_data.xlsx')
    print(f"Stock data saved to '{symbol1}_{symbol2}_stock_data.xlsx'")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Download, preprocess, and select pairs of stocks.')
    parser.add_argument('symbol1', type=str, help='First stock ticker symbol (e.g., AAPL for Apple Inc.)')
    parser.add_argument('symbol2', type=str, help='Second stock ticker symbol')
    args = parser.parse_args()

    start_date = (datetime.now() - timedelta(days=10*365)).strftime('%Y-%m-%d')
    end_date = datetime.now().strftime('%Y-%m-%d')

    symbol1 = args.symbol1
    symbol2 = args.symbol2

    data1 = fetch_price_data(symbol1, start_date, end_date)
    data2 = fetch_price_data(symbol2, start_date, end_date)

    df1 = preprocess_data(data1)
    df2 = preprocess_data(data2)

    correlation_score = find_correlation(df1, df2)
    print(f"Correlation score between {symbol1} and {symbol2}: {correlation_score}")

    if correlation_score > 0.85: 
        save_to_excel(df1, df2, symbol1, symbol2)
    else:
        print("Correlation score is not significant. Pair not selected.")
