from alembic import op
import sqlalchemy as sa
from sqlalchemy.engine.reflection import Inspector

# revision identifiers, used by Alembic.
revision = '5dae51bb7acd'
down_revision = 'f84a6743cffe'
branch_labels = None
depends_on = None

def upgrade():
    # Create an Inspector with the current connection
    conn = op.get_bind()
    inspector = Inspector.from_engine(conn)

    # Check if 'api_usage_log' exists and create if not
    if 'api_usage_log' not in inspector.get_table_names():
        op.create_table('api_usage_log',
            sa.Column('id', sa.Integer(), nullable=False),
            sa.Column('endpoint', sa.String(length=255), nullable=True),
            sa.Column('response_status', sa.Integer(), nullable=True),
            sa.Column('timestamp', sa.DateTime(), nullable=True),
            sa.PrimaryKeyConstraint('id')
        )

    # Check if 'user_preference' exists and create if not
    if 'user_preference' not in inspector.get_table_names():
        op.create_table('user_preference',
            sa.Column('id', sa.Integer(), nullable=False),
            sa.Column('user_id', sa.Integer(), nullable=True),
            sa.ForeignKeyConstraint(['user_id'], ['users.id'], ),
            sa.PrimaryKeyConstraint('id')
        )

    # Check if 'historical_analysis' exists and create if not
    if 'historical_analysis' not in inspector.get_table_names():
        op.create_table('historical_analysis',
            sa.Column('id', sa.Integer(), nullable=False),
            sa.Column('user_id', sa.Integer(), nullable=True),
            sa.Column('analysis_type', sa.String(length=50), nullable=True),
            sa.Column('data', sa.JSON(), nullable=True),
            sa.Column('created_at', sa.DateTime(), nullable=True),
            sa.ForeignKeyConstraint(['user_id'], ['user.id'], name='fk_historical_analysis_user_id'),
            sa.PrimaryKeyConstraint('id')
        )

    # Check if 'trading_alert' exists and create if not
    if 'trading_alert' not in inspector.get_table_names():
        op.create_table('trading_alert',
            sa.Column('id', sa.Integer(), nullable=False),
            sa.Column('user_id', sa.Integer(), nullable=True),
            sa.Column('message', sa.String(length=255), nullable=True),
            sa.Column('read', sa.Boolean(), nullable=True),
            sa.Column('created_at', sa.DateTime(), nullable=True),
            sa.ForeignKeyConstraint(['user_id'], ['user.id'], name='fk_trading_alert_user_id'),
            sa.PrimaryKeyConstraint('id')
        )

    # Modifying the 'enrollment' table
    with op.batch_alter_table('enrollment', schema=None) as batch_op:
        batch_op.add_column(sa.Column('user_id', sa.Integer(), nullable=True))
        batch_op.add_column(sa.Column('dark_mode', sa.Boolean(), nullable=True))
        batch_op.add_column(sa.Column('default_strategy', sa.String(length=50), nullable=True))
        batch_op.create_foreign_key('fk_enrollment_user_id', 'user', ['user_id'], ['id'])

def downgrade():
    # This should reverse the changes made in the upgrade function
    with op.batch_alter_table('enrollment', schema=None) as batch_op:
        batch_op.drop_constraint('fk_enrollment_user_id', type_='foreignkey')
        batch_op.drop_column('default_strategy')
        batch_op.drop_column('dark_mode')
        batch_op.drop_column('user_id')

    op.drop_table('trading_alert')
    op.drop_table('historical_analysis')
    op.drop_table('user_preference')
    op.drop_table('api_usage_log')
