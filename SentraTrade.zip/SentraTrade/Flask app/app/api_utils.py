from flask import current_app
import requests

def fetch_stock_news(api_key, stock_symbol='AAPL'):
    newsapi_url = "https://newsapi.org/v2/everything"
    params = {
        'q': stock_symbol,
        'apiKey': api_key
    }
    response = requests.get(newsapi_url, params=params)
    if response.status_code == 200:
        articles = response.json().get('articles', [])
        return articles[:5]  # Return only the first 5 articles
    return []

def fetch_stock_price(api_key, stock_symbol):
    api_url = f"https://www.alphavantage.co/query?function=TIME_SERIES_INTRADAY&symbol={stock_symbol}&interval=5min&apikey={api_key}"
    try:
        response = requests.get(api_url)
        data = response.json()
        print("API response:", data)  # Debugging: Print API response to help diagnose issues

        # Check if the expected data is available
        if 'Time Series (5min)' in data:
            last_refresh = list(data['Time Series (5min)'].values())[0]
            last_price = last_refresh['4. close']  # Assuming you want the closing price
            return last_price
        else:
            # Handle cases where the data is not available
            if 'Note' in data:
                return f"API Call Limit Exceeded: {data['Note']}"
            elif 'Error Message' in data:
                return f"Error: {data['Error Message']}"
            return "No data available"
    except Exception as e:
        # Handle any other exceptions that could be raised by requests or data access
        print("An error occurred:", e)
        return "Error fetching data"