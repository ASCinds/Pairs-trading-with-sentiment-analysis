from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField, SelectMultipleField, validators,TextAreaField
from wtforms.validators import DataRequired, Email, EqualTo, ValidationError

class RegistrationForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), validators.Length(min=4, max=20)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired(), validators.Length(min=6)])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Register')

class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember = BooleanField('Remember Me')
    submit = SubmitField('Login')

class EnrollmentForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    interests = SelectMultipleField('Select Interests', choices=[
        ('stat_arbitrage', 'Statistical Arbitrage'),
        ('momentum_trading', 'Momentum Trading'),
        ('market_making', 'Market Making'),
        ('sentiment_analysis', 'Sentiment Analysis'),
        ('algo_execution', 'Algorithmic Execution'),
        ('multi_factor', 'Multi-factor Models'),
        ('anomaly_detection', 'Anomaly Detection'),
        ('price_forecasting', 'Deep Learning for Price Forecasting')
    ], validators=[DataRequired()])
    submit = SubmitField('Enroll')

class ContactForm(FlaskForm):
    name = StringField('Name', validators=[DataRequired()])
    email = StringField('Email', validators=[DataRequired(), Email()])
    message = TextAreaField('Message', validators=[DataRequired()])
    submit = SubmitField('Send')

